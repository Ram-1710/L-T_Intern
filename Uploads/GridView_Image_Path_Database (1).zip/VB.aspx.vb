﻿Imports System.IO
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
            Using conn As SqlConnection = New SqlConnection(constr)
                Using sda As SqlDataAdapter = New SqlDataAdapter("SELECT * FROM Files", conn)
                    Dim dt As DataTable = New DataTable()
                    sda.Fill(dt)
                    gvImages.DataSource = dt
                    gvImages.DataBind()
                End Using
            End Using
        End If
    End Sub

    Protected Sub Upload(ByVal sender As Object, ByVal e As EventArgs)
        'Extract Image File Name.
        Dim fileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)

        'Set the Image File Path.
        Dim filePath As String = "~/Uploads/" & fileName

        'Save the Image File in Folder.
        FileUpload1.PostedFile.SaveAs(Server.MapPath(filePath))

        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using conn As SqlConnection = New SqlConnection(constr)
            Dim sql As String = "INSERT INTO Files VALUES(@Name, @Path)"
            Using cmd As SqlCommand = New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@Name", fileName)
                cmd.Parameters.AddWithValue("@Path", filePath)
                conn.Open()
                cmd.ExecuteNonQuery()
                conn.Close()
            End Using
        End Using

        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub
End Class
