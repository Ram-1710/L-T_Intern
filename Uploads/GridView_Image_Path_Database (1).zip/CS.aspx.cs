﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class CS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(constr))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Files", conn))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    gvImages.DataSource = dt;
                    gvImages.DataBind();
                }
            }
        }
    }

    protected void Upload(object sender, EventArgs e)
    {
        //Extract Image File Name.
        string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);

        //Set the Image File Path.
        string filePath = "~/Uploads/" + fileName;

        //Save the Image File in Folder.
        FileUpload1.PostedFile.SaveAs(Server.MapPath(filePath));

        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(constr))
        {
            string sql = "INSERT INTO Files VALUES(@Name, @Path)";
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Name", fileName);
                cmd.Parameters.AddWithValue("@Path", filePath);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        Response.Redirect(Request.Url.AbsoluteUri);
    }
}